package IC;

import java.util.Comparator;

public abstract class MyPrimitiveType extends MyType {
	
	public String toString(){
		return "Primitive type: "+this.getName();
	}
	
}
